<?php $__env->startSection('content'); ?>
<div class="flex justify-center">
    <div class="w-full max-w-2xl">
        <div class="bg-white dark:bg-gray-800 shadow rounded-lg overflow-hidden">
            <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-700 font-bold text-gray-900 dark:text-white">
                <?php echo e(__('Dashboard')); ?>

            </div>

            <div class="p-6 text-gray-900 dark:text-gray-300">
                <?php if(session('status')): ?>
                    <div class="p-4 mb-4 text-sm text-green-800 rounded-lg bg-green-50 dark:bg-gray-800 dark:text-green-400" role="alert">
                        <?php echo e(session('status')); ?>

                    </div>
                <?php endif; ?>

                <?php echo e(__('You are logged in!')); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_nextkit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\smartmed3\resources\views/home.blade.php ENDPATH**/ ?>