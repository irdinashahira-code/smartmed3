# Deployment Guide: Shared Hosting (cPanel/FTP)

This guide is for deploying to standard Shared Hosting services (like Hostinger, Namecheap, Bluehost, or free options like InfinityFree/000webhost).

## Recommended Hosting Specs
For this specific project (**Laravel 10**), you need a hosting plan that meets these requirements:

*   **PHP Version**: **8.1 or higher** (Critical)
*   **Database**: MySQL or MariaDB
*   **SSL**: Free SSL Certificate (Required for security)
*   **Cron Jobs**: Ability to run scheduled tasks (for Appointment Reminders)
*   **SSH Access**: Highly Recommended (makes running commands much easier)

**Plan Recommendation**:
*   For **1 Website**, a "Single" or "Starter" Shared Hosting plan is usually sufficient.
*   Ensure the plan offers at least **1GB RAM** and **10GB Storage**.

---

## Prerequisites
1.  **Hosting Account**: A cPanel or DirectAdmin based hosting.
2.  **File Manager**: Access via browser or FTP client (like FileZilla).
3.  **Database**: Access to phpMyAdmin on your host.

---

## Step 1: Prepare Your Project Locally

Before uploading, you need to prepare the files on your computer.

1.  **Build Frontend Assets**:
    Open your terminal in VS Code and run:
    ```bash
    npm run build
    ```

2.  **Prepare Dependencies**:
    *   **Recommended**: If your host has SSH, run `composer install` on the server.
    *   **Easy Way (No SSH)**: Run this locally to prepare the `vendor` folder:
        ```bash
        composer install --optimize-autoloader --no-dev
        ```
    *(Note: This assumes your local PHP version matches the server's PHP version. Ensure your host supports PHP 8.1+).*

3.  **Clean Caches**:
    ```bash
    php artisan config:clear
    php artisan route:clear
    php artisan view:clear
    ```

4.  **Zip the Project**:
    Select ALL files in your project folder **EXCEPT**:
    *   `node_modules` (folder)
    *   `.git` (folder)
    *   `.idea` or `.vscode` (folders)
    
    Right-click and **Compress to ZIP** file (e.g., `smartmed.zip`).

---

## Step 2: Database Setup

1.  **Export Local Database**:
    *   Open **Laragon Database** (HeidiSQL or phpMyAdmin).
    *   Select your database (`smartmed3`).
    *   Right-click -> **Export database as SQL**.
    *   Save it as `db_backup.sql`.

2.  **Create Remote Database**:
    *   Log in to your Hosting cPanel.
    *   Go to **MySQL Databases**.
    *   Create a new Database (e.g., `u12345_smartmed`).
    *   Create a new User and Password.
    *   **Add User to Database** with "ALL PRIVILEGES".
    *   **Note down**: Database Name, Username, and Password.

3.  **Import SQL**:
    *   Go to **phpMyAdmin** in cPanel.
    *   Select your new empty database.
    *   Click **Import** tab.
    *   Choose your `db_backup.sql` file and click **Go**.

---

## Step 3: Upload Files

We will use the "Separated" method which is more secure.

1.  **Log in to File Manager** (cPanel).
2.  **Create a Folder for Code**:
    *   Go to the root directory (usually one level UP from `public_html`).
    *   Create a folder named `smartmed_core`.
3.  **Upload & Extract**:
    *   Upload `smartmed.zip` inside `smartmed_core`.
    *   **Extract** it there.
    *   You should see `app`, `bootstrap`, `vendor`, etc., inside `smartmed_core`.

4.  **Move Public Files**:
    *   Go into `smartmed_core/public`.
    *   **Select All** files.
    *   **Move** them to `public_html` (your main public folder).
    *   (Delete the empty `smartmed_core/public` folder afterwards).

---

## Step 4: Configure the Application

Now we need to tell the public files where the rest of the application is.

1.  **Edit `index.php`**:
    *   Go to `public_html/index.php`.
    *   Right-click -> **Edit**.
    *   Find these lines and update the paths to point to your `smartmed_core` folder:

    **Change line 34 (Maintenance):**
    ```php
    if (file_exists(__DIR__.'/../smartmed_core/storage/framework/maintenance.php')) {
        require __DIR__.'/../smartmed_core/storage/framework/maintenance.php';
    }
    ```

    **Change line 52 (Autoload):**
    ```php
    require __DIR__.'/../smartmed_core/vendor/autoload.php';
    ```

    **Change line 67 (Bootstrap):**
    ```php
    $app = require_once __DIR__.'/../smartmed_core/bootstrap/app.php';
    ```
    *   Save changes.

2.  **Edit `.env` File**:
    *   Go to `smartmed_core/.env`.
    *   Edit it with your production details:

    ```ini
    APP_NAME=SmartMed
    APP_ENV=production
    APP_DEBUG=false
    APP_URL=http://your-domain.com

    DB_CONNECTION=mysql
    DB_HOST=127.0.0.1  # Usually localhost for shared hosting
    DB_PORT=3306
    DB_DATABASE=u12345_smartmed  # Your cPanel DB Name
    DB_USERNAME=u12345_user      # Your cPanel User
    DB_PASSWORD=your_password

    # ... keep other settings
    ```

3.  **Fix Storage Link** (Important for images):
    Since we can't run commands easily, we can simulate the symlink.
    *   In `public_html`, create a folder named `storage`.
    *   *Actually, shared hosting symlinks are tricky.*
    *   **Best Method**:
        *   Delete `public_html/storage` folder if it exists.
        *   In cPanel, look for "Cron Jobs" or "Terminal" to run:
            `ln -s /path/to/smartmed_core/storage/app/public /path/to/public_html/storage`
        *   **Alternative (PHP Script)**: Create a file `link.php` in `public_html`:
            ```php
            <?php
            symlink('/home/username/smartmed_core/storage/app/public', '/home/username/public_html/storage');
            echo "Done";
            ?>
            ```
            Run it once (`your-domain.com/link.php`) and then delete it.

---

## Step 5: Set Up Cron Jobs (Important)

Your project has scheduled tasks (Appointment Reminders). You need to set up a Cron Job in cPanel.

1.  Go to **Cron Jobs** in cPanel.
2.  Add a new Cron Job:
    *   **Common Settings**: Once per minute (`* * * * *`)
    *   **Command**:
        ```bash
        /usr/local/bin/php /home/username/smartmed_core/artisan schedule:run >> /dev/null 2>&1
        ```
    *(Note: Replace `/home/username/` with your actual path. You can find the path in the File Manager).*

---

## Troubleshooting

*   **HTTP 500 Error**:
    *   Check `.env` credentials.
    *   Check `smartmed_core/storage/logs/laravel.log`.
    *   Ensure file permissions: `storage` and `bootstrap/cache` folders need **775** or **777** permissions.
*   **Images 404**:
    *   The symbolic link is broken. Try the PHP Script method above.
